Facebook Saved Extractor V1.5.0

Base: FacebookSavedExtractor-V1.3.0.

Ajustes de esta versión:
- Extracción textual basada en la representación más completa del enlace del post.
- No se usa line-clamp como criterio de selección.
- Se evita concatenar las representaciones duplicadas de Facebook.
- Se conservan los hashtags finales y el contenido completo disponible en el DOM.
- Duración de Reel/Video conservada como HH:MM|texto.
- tipo_post incluye post_url para enlaces externos/redirecciones.
- Modo normal: 30 posts nuevos antes de entrar a Messenger.
- Modo objetivo: objetivo + exactamente 3 posts posteriores.
- Messenger: un post por vez.
- Compositor localizado específicamente como editor Lexical de Messenger.
- El envío no se considera confirmado hasta que el compositor se vacía y aparece el mensaje en el historial.
- Si el envío no puede verificarse, el post no se purga ni se marca como copiado.
- Purga únicamente después de confirmación.
- Inicio exclusivamente mediante INICIAR.
- Panel claro, centrado y ampliado para modo escritorio.
- Estados visibles: DETENIDO, INICIANDO, ESCANEO INICIAL, ESCANEANDO, SCROLL,
  ESPERANDO, CRECIMIENTO DETECTADO, COPIANDO, PURGANDO y NUEVO CICLO.
- Estadísticas simplificadas según la especificación del proyecto.

Instalación manual:
1. Crear una carpeta.
2. Colocar directamente en ella manifest.json, content.js, panel.css y README.txt.
3. Comprimir el contenido de la carpeta en ZIP si Firefox solicita un paquete.
4. Instalar la extensión en Firefox Android mediante la opción de instalación de extensiones desde archivo.

Importante:
El envío confirmado depende de que Messenger exponga en el DOM el compositor y una representación del mensaje enviado.

V1.6.0: envío Messenger ajustado para usar el botón Enviar real del DOM cuando está disponible; Enter sintético queda como fallback.


V1.6.4: Messenger sendOne restored exactly from FacebookSavedExtractor-V1.3.0/V13.


V1.6.4: Messenger ahora usa exclusivamente el compositor Lexical dentro de [data-scope="messages_table"], evitando inputs de búsqueda u otros campos del DOM.


V1.6.8: paquete regenerado; conserva la lógica V1.6.7, incluido el umbral normal de 30 posts nuevos y FIN OBJETIVO en modo objetivo.

V1.6.10: corrección efectiva del flujo: primeros 30 posts nuevos en orden, lote cerrado, deduplicación antes de Messenger, un solo envío por post y sin reintento automático que pueda duplicar mensajes; purga solo tras confirmación. Modo objetivo preservado.


V1.6.12: separación estricta de estadísticas entre modo normal y modo objetivo; Post Nuevos no se incrementa durante búsqueda de objetivo; lote normal = primeros 30 nuevos en orden.
