(() => {
"use strict";

if (window.__FSE_V16) return;
// V1.6.12: flujo real integrado; lote normal de 30; objetivo independiente; contadores coherentes.
window.__FSE_V16 = true;

const S = {
  running:false, stop:false, target:"", targetMode:false,
  targetFound:false, targetRemaining:null,
  batch:[], processed:new Set(), loadedPosts:new Set(),
  cycle:0, scrolls:0, loaded:0, newCount:0, copied:0, purged:0,
  lastDetected:0, lastNew:0, lastCopied:0, lastPurged:0, pending:0,
  lastHeight:document.documentElement.scrollHeight,
  noGrowth:0, domAccum:0, domPurged:0,
  lastType:"-", lastAuthor:"", lastPostId:"", lastPfbid:"",
  state:"DETENIDO", mutationPending:false
};

const $ = id => document.getElementById(id);

function clean(s){
  return String(s ?? "")
    .replace(/\u00a0/g," ")
    .replace(/\r/g,"")
    .replace(/[ \t]+\n/g,"\n")
    .replace(/\n[ \t]+/g,"\n")
    .replace(/[ \t]{2,}/g," ")
    .replace(/\n{3,}/g,"\n\n")
    .trim();
}
function norm(s){ return clean(s).toLowerCase().replace(/\s+/g," "); }
function urls(r){ return [...r.querySelectorAll("a[href]")].map(a=>a.href).filter(Boolean); }

function postId(u){
  if(!u) return "";
  const ps = [
    /[?&]story_fbid=([^&#]+)/i,
    /[?&]fbid=([^&#]+)/i,
    /\/posts\/(\d+)/i,
    /\/videos\/(\d+)/i,
    /\/reel\/(\d+)/i,
    /\/reels\/(\d+)/i,
    /\/watch\/(?:[?&]v=)?(\d+)/i,
    /[?&]v=(\d+)/i
  ];
  for(const p of ps){
    const m=String(u).match(p);
    if(m) return decodeURIComponent(m[1]);
  }
  return "";
}
function pfbid(u){
  const m=String(u||"").match(/pfbid[A-Za-z0-9_-]+/i);
  return m ? m[0] : "";
}
function ids(u){
  try{
    const x=new URL(u,location.href);
    const g=x.pathname.match(/\/groups\/(\d+)/i);
    return {
      page:x.searchParams.get("id")||x.searchParams.get("profile_id")||x.searchParams.get("user_id")||"",
      group:x.searchParams.get("group_id")||x.searchParams.get("groupid")||(g?g[1]:"")
    };
  }catch{return {page:"",group:""};}
}

function structural(t){
  t=clean(t);
  const m=t.match(/\s*(Reels?|Publicación|Publicacion|Foto|Video)\s*•\s*$/iu);
  if(!m) return {text:t,type:""};
  const x=m[1].toLowerCase();
  const type=/reel/.test(x)?"post_reel":
    /foto/.test(x)?"post_foto":
    /video/.test(x)?"post_video":"post_texto";
  return {text:clean(t.slice(0,m.index)),type};
}

function duration(t){
  const m=String(t||"").match(/^\s*(\d{1,2}:\d{2}(?::\d{2})?)\s*(?=\S)/);
  return m ? m[1]+"|"+clean(String(t).slice(m[0].length)) : clean(t);
}

function isUiText(t){
  return /^(?:Publicación|Publicacion|Reel|Reels|Foto|Video)\s*•/i.test(t) ||
         /^Se guardó(?: en| desde)\b/i.test(t);
}

/*
 * Facebook puede mantener varias representaciones del mismo texto:
 * - una representación visual/truncada;
 * - una representación completa;
 * - duplicados del mismo contenido.
 *
 * La selección NO usa line-clamp como criterio. Se toman candidatos
 * textuales del enlace de la publicación y se conserva la representación
 * más completa, eliminando candidatos que son subconjuntos de otros.
 */
function canonical(container, url){
  const links=[...container.querySelectorAll("a[href]")];
  const postLink =
    links.find(a=>a.href===url) ||
    links.find(a=>/\/(?:posts|reel|reels|videos|watch)\//i.test(a.href||"")) ||
    links.find(a=>pfbid(a.href));

  const roots=[];
  if(postLink) roots.push(postLink);

  /* Fallback: otros enlaces que parezcan ser el contenido del post. */
  for(const a of links){
    if(roots.includes(a)) continue;
    if(/\/(?:posts|reel|reels|videos|watch)\//i.test(a.href||"") || pfbid(a.href))
      roots.push(a);
  }

  const candidates=[];
  const seen=new Set();

  function add(el){
    if(!el) return;
    const t=clean(el.textContent||"");
    if(t.length<8 || isUiText(t)) return;

    const key=norm(t);
    if(seen.has(key)) return;
    seen.add(key);

    /* No penalizamos ni premiamos line-clamp: es solo presentación. */
    candidates.push({text:t, el});
  }

  for(const root of roots){
    add(root);
    root.querySelectorAll("span,div,p").forEach(add);
  }

  /*
   * Si hay más de una representación, una versión corta que está
   * contenida dentro de otra versión larga no gana. El texto más completo
   * se conserva. No concatenamos candidatos.
   */
  candidates.sort((a,b)=>b.text.length-a.text.length);

  for(const c of candidates){
    const st=structural(duration(c.text));
    if(st.text.length>=8) return {text:st.text,type:st.type};
  }

  return {text:"",type:""};
}

function looksLikePostUrl(u){
  return /(?:facebook\.com|fb\.com)/i.test(u) &&
    /\/(?:posts\/|reel\/|reels\/|videos\/|watch\/|permalink\.php|share\/|story\.php)|[?&](?:story_fbid|fbid|v)=|pfbid/i.test(u);
}

function chooseUrl(container){
  const links=[...container.querySelectorAll("a[href]")].filter(a=>a.href);
  const direct=links.map(a=>a.href);

  /* Primero la URL que identifica inequívocamente el post. */
  const post=direct.find(looksLikePostUrl);
  if(post) return post;

  /* Si Facebook presenta un enlace propio que redirige a un sitio externo,
     ese enlace sigue representando un post guardado. */
  const external=direct.find(u=>!/(?:facebook\.com|fb\.com|messenger\.com)/i.test(u));
  if(external) return external;

  return direct[0]||"";
}

function postTypeFromUrl(u){
  if(!u) return "post_url";
  if(/\/(?:reel|reels)\//i.test(u)) return "post_reel";
  if(/\/videos\//i.test(u) || /[?&]v=\d+/i.test(u)) return "post_video";
  if(/\/(?:posts\/|permalink\.php|story\.php|share\/)/i.test(u) ||
     /pfbid/i.test(u) || /[?&](?:story_fbid|fbid)=/i.test(u))
    return "post_texto";
  return "post_url";
}

function containers(){
  const marks=[...document.querySelectorAll("a[href],span,div")].filter(e =>
    /Se guardó desde\s+la publicación de/i.test(e.textContent||"")
  );

  const out=[];
  const seenNodes=new Set();

  for(const m of marks){
    let p=m;
    for(let i=0;i<12 && p;i++,p=p.parentElement){
      const u=chooseUrl(p);
      if(u && !seenNodes.has(p)){
        seenNodes.add(p);
        out.push({container:p,url:u,marker:m});
        break;
      }
    }
  }

  /* Facebook puede exponer el mismo post mediante varios nodos.
     Conservamos el orden físico del DOM. */
  out.sort((a,b)=>{
    if(a.container===b.container) return 0;
    const pos=a.container.compareDocumentPosition(b.container);
    if(pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
    if(pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
    return 0;
  });

  return out;
}

function extractSavedFields(x){
  const root=x.marker || x.container;
  const anchors=[...root.querySelectorAll("a[href]")];

  /* Colección: exclusivamente el enlace de /saved/ que acompaña
     al marcador "Se guardó en". */
  let collection="";
  const ca=anchors.find(a=>/\/saved\/(?:\?|$)/i.test(a.getAttribute("href")||""));
  if(ca) collection=clean(ca.textContent||"");

  /* Autor: exclusivamente el enlace que representa
     "la publicación de [AUTOR]". Normalmente su href es el URL del post. */
  let author="";
  const aa=anchors.find(a=>{
    const h=a.href||"";
    const t=clean(a.textContent||"");
    return looksLikePostUrl(h) && /la publicación de/i.test(t);
  });
  if(aa){
    author=clean((aa.textContent||"").replace(/^la publicación de\s*/i,""));
  }

  /* Fallback estructural: enlace de post dentro del marcador,
     pero nunca tomar texto concatenado del contenedor completo. */
  if(!author){
    const pa=anchors.find(a=>looksLikePostUrl(a.href||""));
    if(pa){
      const t=clean(pa.textContent||"");
      const m=t.match(/la publicación de\s+(.+)$/i);
      if(m) author=clean(m[1]);
    }
  }

  return {author,collection};
}

function parse(x){
  const c=canonical(x.container,x.url);
  const fields=extractSavedFields(x);
  const i=ids(x.url);
  const pf=pfbid(x.url);
  const pid=postId(x.url);
  const type=c.type || postTypeFromUrl(x.url);

  const identity =
    pid ? "pid:"+String(pid) :
    pf ? "pf:"+String(pf).toLowerCase() :
    (looksLikePostUrl(x.url) ? "url:"+norm(x.url) : "struct:"+norm(
      fields.author+"|"+c.text+"|"+fields.collection
    ));

  return {
    _identity:identity,
    _aliases:[],
    _container:x.container,
    id:0,
    post_id:pid,
    pfbid:pf,
    page_or_user_id:i.page,
    group_id:i.group,
    autor:fields.author,
    texto:c.text,
    coleccion:fields.collection,
    tipo_post:type,
    url:x.url
  };
}

function identityKeys(p){
  const keys=new Set();
  if(p.post_id) keys.add("pid:"+String(p.post_id));
  if(p.pfbid) keys.add("pf:"+String(p.pfbid).toLowerCase());
  if(p.url) keys.add("url:"+norm(p.url));
  if(!keys.size) keys.add("struct:"+norm(
    (p.autor||"")+"|"+(p.texto||"")+"|"+(p.coleccion||"")
  ));
  return [...keys];
}

function targetKey(s){
  s=String(s||"").trim();
  return {
    pid:/^\d+$/.test(s)?s:postId(s),
    pf:pfbid(s),
    url:/^https?:/i.test(s)?s:""
  };
}
function isTarget(p){
  if(!S.targetMode) return false;
  const t=targetKey(S.target);
  return (t.pid&&p.post_id===t.pid) ||
         (t.pf&&p.pfbid===t.pf) ||
         (t.url&&p.url===t.url);
}

function setState(state){
  S.state=state;
  const e=$("fse-state");
  if(e) e.textContent=state;
}

function stats(){
  const h=document.documentElement.scrollHeight;
  const current=document.documentElement.outerHTML.length;
  $("fse-stats").innerHTML =
    `<b>ACUMULADO</b><br>`+
    `Post Cargados: ${S.loaded}<br>`+
    `Post Nuevos: ${S.newCount}<br>`+
    `Post Copiados: ${S.copied}<br>`+
    `Post Purgados: ${S.purged}`+
    `<br><br>`+
    `Tamaño DOM actual: ${(current/1048576).toFixed(2)} MB<br>`+
    `Tamaño DOM acumulado: ${(S.domAccum/1048576).toFixed(2)} MB<br>`+
    `Tamaño DOM purgado: ${(S.domPurged/1048576).toFixed(2)} MB`;
}

function panel(){
  if($("fse-panel")) return;
  const p=document.createElement("div");
  p.id="fse-panel";
  p.innerHTML=
    `<div id="fse-title">FACEBOOK SAVED — EXTRACTOR</div>`+
    `<div class="fse-state-label">ESTADO</div>`+
    `<div id="fse-state">DETENIDO</div>`+
    `<div id="fse-stats"></div>`+
    `<div class="fse-target-label">POST OBJETIVO</div>`+
    `<input id="fse-target" type="text" placeholder="ID numérico, postid, pfbid o URL">`+
    `<div class="fse-target-help">Al detectarlo se procesan 3 posts posteriores y se detiene.</div>`+
    `<div class="fse-buttons">`+
      `<button id="fse-start">▶ INICIAR</button>`+
      `<button id="fse-stop">■ DETENER</button>`+
    `</div>`;

  document.documentElement.appendChild(p);
  $("fse-start").onclick=start;
  $("fse-stop").onclick=stop;
  stats();
}

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

/*
 * Abre Messenger desde el botón flotante de Facebook y selecciona
 * exclusivamente el chat "Fuego Vivo". Se ejecuta al pulsar INICIAR,
 * no al cargar la página, para conservar el requisito de inicio manual.
 */
function visible(el){
  if(!el) return false;
  const r=el.getBoundingClientRect();
  const st=getComputedStyle(el);
  return r.width>0 && r.height>0 && st.display!=="none" &&
    st.visibility!=="hidden" && st.opacity!=="0";
}

function exactVisibleText(text){
  const wanted=norm(text);
  const els=[...document.querySelectorAll("a,button,[role='button'],[role='link'],[role='listitem'],div,span")];
  return els.find(e=>{
    if(!visible(e)) return false;
    const t=norm(e.textContent||"");
    return t===wanted;
  }) || null;
}

async function clickMessengerFloating(){
  const selectors=[
    '[aria-label="Messenger"]',
    '[aria-label*="Messenger" i]',
    '[data-testid*="messenger" i]',
    'a[href*="/messages/"]',
    'a[href*="messenger.com"]'
  ];

  for(const sel of selectors){
    const els=[...document.querySelectorAll(sel)];
    const hit=els.find(visible);
    if(hit){
      hit.click();
      await sleep(900);
      return true;
    }
  }

  /* Fallback: botón flotante cuyo texto/aria-label identifica Messenger. */
  const candidates=[...document.querySelectorAll("button,[role='button'],a")];
  const hit=candidates.find(e=>{
    if(!visible(e)) return false;
    const a=norm(e.getAttribute("aria-label")||"");
    const t=norm(e.textContent||"");
    return a==="messenger" || a.includes("messenger") ||
           t==="messenger" || t.includes("messenger");
  });
  if(hit){
    hit.click();
    await sleep(900);
    return true;
  }
  return false;
}

async function openFuegoVivoChat(timeout=7000){
  const deadline=Date.now()+timeout;

  while(Date.now()<deadline){
    /*
     * Primero intentamos controles accesibles que identifiquen directamente
     * el contacto. Esto evita confundir "Fuego Vivo" con texto del historial.
     */
    const controls=[
      ...document.querySelectorAll(
        '[aria-label="Fuego Vivo"],[aria-label*="Fuego Vivo" i],'+
        '[title="Fuego Vivo"],[title*="Fuego Vivo" i]'
      )
    ].filter(visible);

    if(controls.length){
      controls[0].click();
      await sleep(900);
      if(findFuegoHeader()) return true;
    }

    const exact=exactVisibleText("Fuego Vivo");
    if(exact){
      exact.click();
      await sleep(900);
      if(findFuegoHeader()) return true;
    }

    await sleep(250);
  }
  return false;
}

function findFuegoHeader(){
  const wanted=norm("Fuego Vivo");

  /* Encabezados del chat tienen prioridad. */
  const heads=[...document.querySelectorAll("h1,h2,h3,[role='heading']")];
  if(heads.some(e=>visible(e) && norm(e.textContent||"")===wanted)) return true;

  /*
   * Fallback: un control accesible con Fuego Vivo visible junto al
   * compositor del chat. No basta con encontrar texto en el historial.
   */
  const composer=findComposer();
  if(!composer) return false;

  let p=composer;
  for(let i=0;i<8 && p;i++,p=p.parentElement){
    const t=norm(p.textContent||"");
    if(t.includes(wanted)) return true;
  }
  return false;
}

async function ensureMessengerFuegoVivo(){
  /* Si ya estamos en Messenger y el chat correcto está abierto, no tocamos nada. */
  if(findFuegoHeader() && findComposer()) return true;

  const opened=await clickMessengerFloating();

  /* Si el botón no existe, puede que Messenger ya esté abierto como panel. */
  if(!opened && !findComposer()){
    return false;
  }

  return await openFuegoVivoChat(8000);
}


function stop(){
  S.stop=true;
  S.running=false;
  setState("DETENIDO");
  stats();
}

/* Compositor exacto del chat proporcionado por el usuario. */
function findComposer(){
  const candidates=[...document.querySelectorAll(
    'div[contenteditable="true"][role="textbox"][data-lexical-editor="true"],'+
    'div[contenteditable="true"][role="textbox"][aria-placeholder="Aa"],'+
    'div[contenteditable="true"][role="textbox"][aria-label^="Escribe en"]'
  )];

  return candidates.find(e=>{
    const r=e.getBoundingClientRect();
    return r.width>0 && r.height>0 &&
      !e.hasAttribute("disabled") &&
      e.getAttribute("contenteditable")==="true";
  }) || null;
}

function composerText(e){
  return clean(e?.textContent||"");
}

function insertComposer(e,payload){
  e.focus();
  try{ document.execCommand("selectAll",false); }catch{}
  try{ document.execCommand("insertText",false,payload); }catch{}

  /* Fallback para el editor Lexical. */
  if(!composerText(e)){
    const p=e.querySelector("p");
    if(p){
      p.textContent=payload;
      e.dispatchEvent(new InputEvent("input",{
        bubbles:true,inputType:"insertText",data:payload
      }));
    }
  }else{
    e.dispatchEvent(new InputEvent("input",{
      bubbles:true,inputType:"insertText",data:payload
    }));
  }
}

function outgoingCandidates(){
  return [...document.querySelectorAll(
    '[data-testid*="message"], [data-testid*="outgoing"], [role="row"], [role="listitem"]'
  )].filter(e=>{
    const r=e.getBoundingClientRect();
    return r.width>0 && r.height>0;
  });
}

function messageTextCandidates(){
  return outgoingCandidates().map(e=>norm(e.textContent||"")).filter(Boolean);
}

function findSendButton(composer){
  if(!composer) return null;
  const scope = composer.closest('[role="main"]') || composer.parentElement?.parentElement?.parentElement || document;
  const selectors = [
    '[aria-label="Enviar"]',
    '[aria-label="Send"]',
    '[aria-label*="Enviar"]',
    '[aria-label*="Send"]',
    '[data-testid="send-button"]',
    '[data-testid*="send-button"]',
    '[data-testid*="send"]'
  ];
  for(const sel of selectors){
    const els=[...scope.querySelectorAll(sel)];
    const hit=els.find(e=>{
      const r=e.getBoundingClientRect();
      return r.width>0 && r.height>0 && !e.hasAttribute("disabled");
    });
    if(hit) return hit;
  }
  return null;
}

function insertComposer(e,payload){
  e.focus();
  try{ document.execCommand("selectAll",false); }catch{}
  let inserted=false;
  try{ inserted=document.execCommand("insertText",false,payload); }catch{}

  if(!composerText(e)){
    const p=e.querySelector("p");
    if(p){
      p.textContent=payload;
      p.dispatchEvent(new InputEvent("input",{
        bubbles:true,inputType:"insertText",data:payload
      }));
      inserted=true;
    }
  }

  e.dispatchEvent(new InputEvent("input",{
    bubbles:true,inputType:"insertText",data:payload
  }));
  return inserted;
}

async function waitComposerValue(composer,payload,timeout=2500){
  const expected=clean(payload);
  const deadline=Date.now()+timeout;
  while(Date.now()<deadline){
    if(composerText(composer)===expected) return true;
    await sleep(100);
  }
  return composerText(composer)===expected;
}

async function waitComposerEmpty(composer,timeout=4000){
  const deadline=Date.now()+timeout;
  while(Date.now()<deadline){
    if(!composerText(composer)) return true;
    await sleep(150);
  }
  return !composerText(composer);
}

async function waitForMessageInHistory(payload,beforeTexts,timeout=6000){
  const expected=norm(payload);
  const deadline=Date.now()+timeout;
  while(Date.now()<deadline){
    const texts=messageTextCandidates();
    if(texts.some(t=>t===expected || t.includes(expected))) return true;

    /* Fallback: Messenger puede dividir un mensaje en varios nodos. */
    const unique=expected.slice(0,Math.min(120,expected.length));
    if(unique.length>=20 && texts.some(t=>t.includes(unique))) return true;

    await sleep(200);
  }
  return false;
}

async function waitForSendConfirmation(payload,composer,beforeTexts){
  const emptied=await waitComposerEmpty(composer,4000);
  if(!emptied) return false;
  return await waitForMessageInHistory(payload,beforeTexts,6000);
}

async function sendOne(p){
  const o={...p};
  delete o._identity;
  delete o._aliases;
  delete o._container;
  const payload=JSON.stringify(o);
  const expected=norm(payload);

  const e=findComposer();
  if(!e) return false;

  // Limpiar completamente el compositor antes de cada post.
  e.focus();
  try{document.execCommand("selectAll",false);}catch{}
  try{document.execCommand("delete",false);}catch{}
  e.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"deleteContentBackward",data:null}));
  await sleep(150);
  if(composerText(e)) return false;

  // Un solo insertado por post.
  let inserted=false;
  try{inserted=document.execCommand("insertText",false,payload);}catch{}
  if(!inserted || composerText(e)!==clean(payload)){
    e.focus();
    try{document.execCommand("selectAll",false);}catch{}
    const pnode=e.querySelector("p") || e;
    if(pnode!==e) pnode.textContent=payload;
    else e.textContent=payload;
    e.dispatchEvent(new InputEvent("input",{
      bubbles:true,inputType:"insertText",data:payload
    }));
  }

  if(!(await waitComposerValue(e,payload,2500))) return false;

  // El texto existente antes del envío se usa solo como línea base.
  const beforeCount=messageTextCandidates().length;

  e.focus();
  e.dispatchEvent(new KeyboardEvent("keydown",{
    key:"Enter",code:"Enter",keyCode:13,which:13,
    bubbles:true,cancelable:true
  }));
  await sleep(80);
  e.dispatchEvent(new KeyboardEvent("keypress",{
    key:"Enter",code:"Enter",keyCode:13,which:13,
    bubbles:true,cancelable:true
  }));
  await sleep(80);
  e.dispatchEvent(new KeyboardEvent("keyup",{
    key:"Enter",code:"Enter",keyCode:13,which:13,
    bubbles:true,cancelable:true
  }));

  // Confirmación conservadora: el compositor debe quedar vacío y debe
  // existir una representación del payload en el historial. Si el editor
  // se vacía pero la historia aún tarda, esperamos; nunca reenviamos.
  const emptied=await waitComposerEmpty(e,4000);
  if(!emptied) return false;

  const deadline=Date.now()+6000;
  while(Date.now()<deadline){
    const texts=messageTextCandidates();
    if(texts.some(t=>t===expected || t.includes(expected) || expected.includes(t) && t.length>20)){
      return true;
    }
    // Si el número de mensajes aumentó, aceptar únicamente cuando alguno
    // de los nuevos elementos contiene el identificador del post.
    if(texts.length>beforeCount){
      const pid=norm(p.post_id||p.pfbid||"");
      if(pid && texts.some(t=>t.includes(pid))) return true;
    }
    await sleep(200);
  }
  return false;
}

async function processBatch(){
  if(!S.batch.length) return;

  setState("COPIANDO");

  // LOTE CERRADO: únicamente los primeros 30 posts nuevos capturados,
  // en el orden en que fueron detectados. Nunca se vuelve al DOM para
  // reconstruir el lote mientras Messenger está trabajando.
  const b=S.batch.slice(0,30);
  S.batch=S.batch.slice(b.length);

  for(let i=0;i<b.length;i++){
    if(S.stop) break;

    const p=b[i];
    const ok=await sendOne(p);

    // IMPORTANTE: no reintentar automáticamente un Enter cuyo resultado
    // no pudo verificarse. Un reintento puede duplicar un mensaje si
    // Messenger sí lo envió pero la detección falló.
    if(!ok){
      S.batch=b.slice(i).concat(S.batch);
      S.pending=S.batch.length;
      stats();
      setState("DETENIDO");
      return;
    }

    S.copied++;
    S.lastCopied++;

    const n=p._container;
    const sz=n?.outerHTML?.length||0;
    setState("PURGANDO");
    if(n?.isConnected){
      n.remove();
      S.purged++;
      S.lastPurged++;
      S.domPurged+=sz;
    }

    S.pending=b.length-(i+1)+S.batch.length;
    stats();
    await sleep(150);
  }

  if(S.stop){
    setState("DETENIDO");
    stats();
    return;
  }

  S.pending=S.batch.length;
  setState("NUEVO CICLO");
  stats();
}

async function scan(){
  S.lastDetected=0;
  S.lastNew=0;
  S.lastCopied=0;
  S.lastPurged=0;

  const a=containers();
  S.lastDetected=a.length;

  // El contador de cargados representa publicaciones únicas aceptadas por
  // el extractor. Nunca depende de que tengan post_id: se usa la identidad
  // canónica completa como respaldo.
  S.loaded=S.loadedPosts.size;

  const batchIds=new Set();
  for(const q of S.batch) identityKeys(q).forEach(k=>batchIds.add(k));

  for(const x of a){
    if(S.stop) break;

    const p=parse(x);
    if(!p._identity) continue;

    S.lastType=p.tipo_post;
    S.lastAuthor=p.autor;
    S.lastPostId=p.post_id;
    S.lastPfbid=p.pfbid;

    const keys=identityKeys(p);
    if(keys.some(k=>S.processed.has(k) || batchIds.has(k))) continue;

    /*
     * MODO OBJETIVO
     *
     * Mientras se busca el objetivo NO se considera el registro como parte
     * del lote normal y NO incrementa Post Nuevos. Esto evita que el contador
     * crezca mientras se recorre el DOM buscando el objetivo.
     */
    if(S.targetMode){
      if(!S.targetFound){
        if(isTarget(p)){
          // El objetivo sí queda incluido en el último bloque enviado; se
          // agregan exactamente tres publicaciones posteriores.
          S.targetFound=true;
          S.targetRemaining=3;
          p._aliases=keys;
          S.batch.push(p);
          keys.forEach(k=>batchIds.add(k));

          // Registrar la identidad como cargada solo cuando entra realmente
          // al flujo de extracción.
          keys.forEach(k=>S.loadedPosts.add(k));
          S.loaded=S.loadedPosts.size;
          S.domAccum+=p._container?.outerHTML?.length||0;
          S.lastNew++;
        }
      }else{
        p._aliases=keys;
        S.batch.push(p);
        keys.forEach(k=>batchIds.add(k));
        keys.forEach(k=>S.loadedPosts.add(k));
        S.loaded=S.loadedPosts.size;
        S.domAccum+=p._container?.outerHTML?.length||0;
        S.lastNew++;
        S.targetRemaining--;

        if(S.targetRemaining<=0){
          for(const q of S.batch) identityKeys(q).forEach(k=>S.processed.add(k));
          break;
        }
      }

      stats();
      continue;
    }

    /*
     * MODO NORMAL
     *
     * Aquí sí existe el concepto de "Post Nuevos": son exclusivamente los
     * posts únicos que entran al lote normal. Se aceptan en el orden en que
     * aparecen en el DOM y el escaneo se detiene inmediatamente al llegar a
     * 30. No se sigue recorriendo el DOM para llenar un lote posterior.
     */
    p._aliases=keys;
    keys.forEach(k=>S.loadedPosts.add(k));
    S.loaded=S.loadedPosts.size;
    S.newCount++;
    S.lastNew++;
    S.domAccum+=p._container?.outerHTML?.length||0;

    S.batch.push(p);
    keys.forEach(k=>batchIds.add(k));

    if(S.batch.length>=30){
      for(const q of S.batch) identityKeys(q).forEach(k=>S.processed.add(k));
      break;
    }

    stats();
  }

  S.loaded=S.loadedPosts.size;
  S.pending=S.batch.length;
  stats();
}
async function scrollOnce(){
  const before=document.documentElement.scrollHeight;
  setState("SCROLL");
  window.scrollBy({top:500,left:0,behavior:"smooth"});
  S.scrolls++;

  setState("ESPERANDO");
  await sleep(S.noGrowth>=2 ? 6000 : 3000);

  const after=document.documentElement.scrollHeight;
  if(after>before){
    S.noGrowth=0;
    setState("CRECIMIENTO DETECTADO");
  }else{
    S.noGrowth++;
  }

  S.lastHeight=after;
  stats();
}

async function start(){
  if(S.running) return;

  S.running=true;
  S.stop=false;
  S.target=$("fse-target").value.trim();
  S.targetMode=!!S.target;
  S.targetFound=false;
  S.targetRemaining=null;
  S.batch=[];

  setState("INICIANDO");
  stats();
  await sleep(250);

  if(S.stop) return;

  /*
   * Antes de extraer el primer lote se abre Messenger mediante el botón
   * flotante de Facebook y se selecciona exactamente "Fuego Vivo".
   * El extractor sigue sin arrancar automáticamente: esto ocurre solo
   * después del clic del usuario en INICIAR.
   */
  const chatReady=await ensureMessengerFuegoVivo();
  if(!chatReady){
    S.running=false;
    setState("DETENIDO");
    stats();
    return;
  }

  if(S.stop) return;

  setState("ESCANEO INICIAL");
  await scan();

  while(S.running && !S.stop){
    if(S.targetFound && S.targetRemaining===0){
      await processBatch();
      S.running=false;
      S.stop=false;
      setState("FIN OBJETIVO");
      stats();
      return;
    }

    if(!S.targetMode && S.batch.length>=30){
      await processBatch();
      if(S.stop) return;
      continue;
    }

    setState("SCROLL");
    await scrollOnce();

    if(S.stop) return;

    setState("ESCANEANDO");
    await scan();

    if(S.targetFound && S.targetRemaining===0){
      await processBatch();
      S.running=false;
      S.stop=false;
      setState("FIN OBJETIVO");
      stats();
      return;
    }

    if(!S.targetMode && S.batch.length>=30){
      await processBatch();
      if(S.stop) return;
      continue;
    }

    setState("NUEVO CICLO");
    await sleep(100);
  }
}

/* Solo se registra la mutación; no dispara una extracción paralela.
   El escaneo controlado sigue siendo responsabilidad del ciclo principal. */
new MutationObserver(()=>{ S.mutationPending=true; })
  .observe(document.documentElement,{subtree:true,childList:true});

panel();

})();
